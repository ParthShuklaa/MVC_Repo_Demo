﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace RepositoryWalkthrough.Models.DAL
{
    public class DepartmentRepository:IDepartmentRepository
    {
        private AniketKMVCDatabaseEntities db;
        public DepartmentRepository()
        {
            db = new AniketKMVCDatabaseEntities();
        }
        public DepartmentRepository(AniketKMVCDatabaseEntities db)
        {
            this.db = db;
        }
        public IEnumerable<Department> GetDepartmentList()
        {
            return db.Departments.ToList();
        }

        public Department GetDepartmentById(int? DeptId)
        {
            return db.Departments.Find(DeptId);
        }

        public void InsertDepartment(Department dept)
        {
            db.Departments.Add(dept);
        }

        public void UpdateDepartment(Department dept)
        {
            db.Entry(dept).State = EntityState.Modified;
        }

        public void DeleteDepartment(int DeptId)
        {
            Department dept = db.Departments.Find(DeptId);
            db.Departments.Remove(dept);
        }

        public void Save()
        {
            db.SaveChanges();
        }
    }
}