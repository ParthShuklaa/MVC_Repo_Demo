﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryWalkthrough.Models.DAL
{
   public interface IDepartmentRepository
    {
       IEnumerable<Department> GetDepartmentList();
       Department GetDepartmentById(int? DeptId);
       void InsertDepartment(Department dept);
       void UpdateDepartment(Department dept);
       void DeleteDepartment(int DeptId);
       void Save();
    }
}
